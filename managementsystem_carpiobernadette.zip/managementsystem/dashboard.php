
<?php
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

function getCount($conn, $table) {
    $allowed = ['users', 'members', 'attendance'];

    if (!in_array($table, $allowed, true)) return 0;

    $check = mysqli_query($conn, "SHOW TABLES");
    if (!$check) return 0;

    while ($row = mysqli_fetch_array($check)) {
        if ($row[0] === $table) {
            $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM `$table`");

            if ($result) {
                $data = mysqli_fetch_assoc($result);
                return (int)$data['total'];
            }
        }
    }

    return 0;
}

$totalUsers = getCount($conn, 'users');
$totalMembers = getCount($conn, 'members');
$totalAttendance = getCount($conn, 'attendance');

$username = $_SESSION['username'] ?? 'User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SK Management Dashboard</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
            color: black;
        }

        .navbar {
            padding: 20px 30px;
            background: transparent;
        }

        .navbar a {
            color: black;
            text-decoration: none;
            margin-right: 25px;
            font-size: 15px;
        }

        .navbar a:hover {
            text-decoration: underline;
        }

        .main {
            padding: 10px 30px;
        }

        .header {
            margin-bottom: 30px;
        }

        .header h2 {
            margin-bottom: 8px;
        }

        .cards {
            display: flex;
            gap: 20px;
        }

        .card {
            background: white;
            border: 1px solid #ddd;
            padding: 20px;
            width: 220px;
        }

        .card h3 {
            font-size: 16px;
            font-weight: normal;
            color: #555;
        }

        .card p {
            font-size: 30px;
            font-weight: bold;
            margin-bottom: 0;
        }

        @media(max-width: 700px) {
            .navbar a {
                display: inline-block;
                margin: 5px 12px 5px 0;
            }

            .cards {
                flex-direction: column;
            }

            .card {
                width: auto;
            }
        }
    </style>
</head>

<body>

    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="members.php">Members</a>
        <a href="attendance.php">Attendance</a>
        <a href="settings.php">Settings</a>
        <a href="index.php">Logout</a>

    </div>

    <div class="main">

        <div class="cards">

            <div class="card">
                <h3>Total Users</h3>
                <p><?php echo $totalUsers; ?></p>
            </div>

            <div class="card">
                <h3>Total Members</h3>
                <p><?php echo $totalMembers; ?></p>
            </div>

            <div class="card">
                <h3>Total Attendance</h3>
                <p><?php echo $totalAttendance; ?></p>
            </div>

        </div>

    </div>
   
           


</body>
</html>
