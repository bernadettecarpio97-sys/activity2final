
<?php
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$message = "";

function h($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

// Add attendance
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_attendance'])) {

    $member_name = trim($_POST['member_name'] ?? '');
    $date = $_POST['date'] ?? '';
    $status = $_POST['status'] ?? '';

    if ($member_name !== "" && $date !== "" &&
        in_array($status, ['Present', 'Absent'], true)) {

        $stmt = mysqli_prepare($conn,
            "INSERT INTO attendance (member_name, date, status)
             VALUES (?, ?, ?)"
        );

        mysqli_stmt_bind_param($stmt, "sss", $member_name, $date, $status);

        if (mysqli_stmt_execute($stmt)) {
            $message = "Attendance saved successfully!";
        } else {
            $message = "Error saving attendance.";
        }

        mysqli_stmt_close($stmt);

    } else {
        $message = "Please complete all fields.";
    }
}

// Display attendance
$result = mysqli_query($conn, "SELECT * FROM attendance ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attendance</title>

    <style>
        body {
            font-family: Arial;
            margin: 30px;
            background: #f4f4f4;
        }

        nav {
            margin-bottom: 30px;
        }

        nav a {
            color: black;
            text-decoration: none;
            margin-right: 20px;
        }

        nav a:hover {
            text-decoration: underline;
        }

        input, select, button {
            padding: 8px;
            margin: 5px;
        }

        button {
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background: #eee;
        }
    </style>
</head>

<body>

<nav>
    <a href="dashboard.php">Dashboard</a>
    <a href="members.php">Members</a>
    <a href="attendance.php">Attendance</a>
    <a href="settings.php">Settings</a>
    <a href="index.php">Logout</a>
</nav>

<h2>Attendance</h2>
<p>Record and view attendance.</p>

<p><?php echo h($message); ?></p>

<h3>Record Attendance</h3>

<form method="POST">

    <input type="text" name="member_name"
           placeholder="Member Name" required>

    <input type="date" name="date"
           value="<?php echo date('Y-m-d'); ?>" required>

    <select name="status" required>
        <option value="">Select Status</option>
        <option value="Present">Present</option>
        <option value="Absent">Absent</option>
    </select>

    <button type="submit" name="add_attendance">
        Save Attendance
    </button>

</form>

<h3>Attendance List</h3>

<table>
    <tr>
        <th>ID</th>
        <th>Member Name</th>
        <th>Date</th>
        <th>Status</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)): ?>
    <tr>
        <td><?php echo h($row['id']); ?></td>
        <td><?php echo h($row['member_name']); ?></td>
        <td><?php echo h($row['date']); ?></td>
        <td><?php echo h($row['status']); ?></td>
    </tr>
    <?php endwhile; ?>

</table>

</body>
</html>
