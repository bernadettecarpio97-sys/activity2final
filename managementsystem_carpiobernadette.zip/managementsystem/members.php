
<?php
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_member'])) {
    $name = trim($_POST['name'] ?? '');
    $age = (int)($_POST['age'] ?? 0);
    $gender = trim($_POST['gender'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if ($name && $age > 0 && $gender && $address) {
        $stmt = mysqli_prepare($conn,
            "INSERT INTO members (name, age, gender, address) VALUES (?, ?, ?, ?)"
        );

        mysqli_stmt_bind_param($stmt, "siss", $name, $age, $gender, $address);

        if (mysqli_stmt_execute($stmt)) {
            $message = "Member added successfully!";
        } else {
            $message = "Error adding member.";
        }

        mysqli_stmt_close($stmt);
    } else {
        $message = "Please complete all fields.";
    }
}

$result = mysqli_query($conn, "SELECT * FROM members ORDER BY id DESC");

function h($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Members</title>
<style>
body {font-family:Arial; margin:30px; background:#f4f4f4;}
nav {margin-bottom:30px;}
nav a {color:black; text-decoration:none; margin-right:20px;}
nav a:hover {text-decoration:underline;}
input, select, button {padding:8px; margin:5px;}
button {cursor:pointer;}
table {width:100%; border-collapse:collapse; margin-top:20px; background:white;}
th, td {border:1px solid #ccc; padding:10px; text-align:left;}
th {background:#eee;}
</style>
</head>
<body>

<nav>
<a href="dashboard.php">Dashboard</a>
<a href="members.php">Members</a>
<a href="attendance.php">Attendance</a>
<a href="settings.php">Settings</a>
<a href="index.php">Logout</a>
</nav>

<h2>Members</h2>
<p>Manage SK members here.</p>

<p><?php echo h($message); ?></p>

<h3>Add Member</h3>

<form method="POST">
<input type="text" name="name" placeholder="Full Name" required>
<input type="number" name="age" placeholder="Age" min="1" required>

<select name="gender" required>
<option value="">Select Gender</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
</select>

<input type="text" name="address" placeholder="Address" required>
<button type="submit" name="add_member">Add Member</button>
</form>

<h3>Members List</h3>

<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>Age</th>
<th>Gender</th>
<th>Address</th>
</tr>

<?php if ($result): ?>
<?php while ($row = mysqli_fetch_assoc($result)): ?>
<tr>
<td><?php echo h($row['id']); ?></td>
<td><?php echo h($row['name']); ?></td>
<td><?php echo h($row['age']); ?></td>
<td><?php echo h($row['gender']); ?></td>
<td><?php echo h($row['address']); ?></td>
</tr>
<?php endwhile; ?>
<?php endif; ?>

</table>

</body>
</html>
