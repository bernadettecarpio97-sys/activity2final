
<?php
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'] ?? 'User';
?>

<!DOCTYPE html>
<html>
<head>
<title>Settings</title>
<style>
body {
    font-family:Arial;
    margin:30px;
    background:#f4f4f4;
}

nav {
    margin-bottom:30px;
}

nav a {
    color:black;
    text-decoration:none;
    margin-right:20px;
}

nav a:hover {
    text-decoration:underline;
}
</style>
</head>
<body>

<nav>
<a href="dashboard.php">Dashboard</a>
<a href="members.php">Members</a>
<a href="attendance.php">Attendance</a>
<a href="settings.php">Settings</a>
<a href="index.php">Logout</a>
</nav>

<h2>Settings</h2>
<p>Account Information</p>

<p><strong>System Name:</strong> SK Management System</p>

<p><strong>Username:</strong>
<?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>
</p>

<p><strong>Account ID:</strong>
<?php echo (int)$_SESSION['user_id']; ?>
</p>

<p><strong>Status:</strong> Active</p>

</body>
</html>
